﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection.Metadata.Ecma335;
using System.Text;
using System.Threading.Tasks;

namespace Rocio.DeGrazia.A323
{
    public class CentroDeAtencion
    {
        private List<Empleado> empleados;
        private int cantRacsPorSuper;
        private string nombre;

        public CentroDeAtencion(string nombre, int cantRacsPorSuper)
        {
            this.nombre = nombre;
            this.cantRacsPorSuper = cantRacsPorSuper;
            empleados = new List<Empleado>();
        }

        public int CantRacsPorSuper
        {
            get
            {
                return cantRacsPorSuper;
            }
        }

        public string Nombre
        {
            get
            {
                return nombre;
            }
        }

        public List<Empleado> Empleados
        {
            get
            {
                return empleados;
            }
        }

        private bool ValidaCantidadDeRacs()
        {
            int cantidadRacs = 0;
            int cantidadSupervisores = 0;

            foreach (Empleado empleado in empleados)
            {
                if (empleado is Rac)
                {
                    cantidadRacs++;
                }
                else if (empleado is Supervisor)
                {
                    cantidadSupervisores++;
                }

            }
            if (cantidadRacs > cantidadSupervisores * cantRacsPorSuper)
            {
                return true;
            }
            else
            {
                return false;
            }
        }

        public static bool operator ==(CentroDeAtencion c, Empleado e)
        {
            foreach (Empleado empleado in c.Empleados)
            {
                if (empleado == e)
                {
                    return true;
                }
            }
            return false;
        }

        public static bool operator !=(CentroDeAtencion c, Empleado e)
        {
            return !(c == e);
        }

        public static CentroDeAtencion operator +(CentroDeAtencion c, Empleado e)
        {
            
            bool empleadoYaExiste = false;
            foreach (Empleado empleado in c.Empleados)
            {
                if (empleado == e)
                {
                    empleadoYaExiste = true;
                    break;
                }
            }

            if (!empleadoYaExiste)
            {
                if (e is Rac)
                {
                    c.Empleados.Add(e);
                }
                else if (e is Supervisor)
                {
                    if (c.ValidaCantidadDeRacs())
                    {
                        c.Empleados.Add(e);
                    }
                }
            }
            return c;
        }

        public static string operator -(CentroDeAtencion c, Empleado e)
        {
            if (c == e)
            {
                e.HoraEgreso = DateTime.Now.TimeOfDay;
                c.Empleados.Remove(e);
                if (e is Supervisor supervisor)
                {
                    return supervisor.EmitirFactura();
                }
                else
                {
                    return "Empleado removido";
                }
            }
            else
            {
                return "Empleado no encontrado";
            }
        }

        public string ImprimirNomina()
        {
            StringBuilder sb = new StringBuilder();
            foreach (Empleado e in Empleados)
            {
                sb.AppendLine(e.ToString());
            }
            return sb.ToString();
        }
    }
}
