﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Rocio.DeGrazia.A323
{  
    public class Rac: Empleado
    {
        private EGrupo grupo = EGrupo.CALL_IN;
        private static double valorHora = 875.90F;

        public Rac(string nombre, string legajo, TimeSpan horaIngreso, EGrupo grupo = EGrupo.CALL_IN) 
            : base(nombre, legajo, horaIngreso)
        {
            this.grupo = grupo;
        }

        public EGrupo Grupo
        {
            get
            {
                return grupo;
            }
        }

        public static double ValorHora
        {
            get { return valorHora; }
            set { if (value > 0) valorHora = value; }
        }

        public string EmitirFactura()
        {
            return $"Factura de: {Nombre} - {Legajo} \n Importe a facturar: {Facturar()}";
        }

        public double CalcularBono()
        {
           if (this.grupo == EGrupo.CALL_IN)
            {
                return 0;
            }
           else if (this.grupo == EGrupo.CALL_OUT)
            {
                return 0.1;
            }
           else //EGrupo.RRS
            {
                return 0.2;
            }

        }

        public override double Facturar()
        {
            return (HoraEgreso - HoraIngreso).TotalHours * (ValorHora * (1 + CalcularBono()));
        }

        public override string ToString()
        {
            return $"{this.GetType().Name} - {Grupo} - {Legajo} - {Nombre}";
        }


        public enum EGrupo { CALL_IN, CALL_OUT, RRSS }
    }
}
