﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Text;
using System.Threading.Tasks;

namespace Rocio.DeGrazia.A323
{
    public abstract class Empleado
    {
        protected TimeSpan horaIngreso;
        protected TimeSpan horaEgreso;
        protected string legajo;
        protected string nombre;

        protected Empleado(string nombre, string legajo, TimeSpan horaIngreso)
        {
            this.horaIngreso = horaIngreso;
            this.legajo = legajo;
            this.nombre = nombre;
        }

        public string Nombre
        {
            get
            {
                return nombre;
            }
        }

        public string Legajo
        {
            get
            {
                return legajo;
            }
        }

        public TimeSpan HoraIngreso
        {
            get
            {
                return horaIngreso;
            }
        }
        public TimeSpan HoraEgreso
        {
            get { return horaEgreso; }
            set { horaEgreso = ValidarHoraEgreso(value); }
        }

        private TimeSpan ValidarHoraEgreso(TimeSpan horaEgreso)
        {
            return horaEgreso > horaIngreso ? horaEgreso : DateTime.Now.TimeOfDay;
        }

        protected virtual double Facturar()
        {
            return (HoraEgreso - HoraIngreso).TotalHours;
        }

        public static bool operator ==(Empleado e1, Empleado e2)
        {
            return e1.Legajo == e2.Legajo;
        }

        public static bool operator !=(Empleado e1, Empleado e2)
        {
            return !(e1 == e2);
        }
    }
}
