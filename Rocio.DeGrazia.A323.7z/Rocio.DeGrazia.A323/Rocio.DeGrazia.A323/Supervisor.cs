﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Rocio.DeGrazia.A323
{
    public class Supervisor : Empleado
    {
        private static float valorHora = 1025.50F;

        private Supervisor(string legajo) : base("n/a",legajo, new TimeSpan(09, 00, 00)) { }

        public Supervisor(string legajo, string nombre, TimeSpan horaIngreso) : base(nombre, legajo, horaIngreso) { }
        public static float ValorHora
        {
            get { return valorHora; }
            set { if (value > 0) valorHora = value; }
        }

        public string EmitirFactura()
        {
            return $"Factura de {this.ToString()}\n Importe a facturar: {Facturar()}";
        }
        protected override double Facturar()
        {
            return (HoraEgreso - HoraIngreso).TotalHours * valorHora;
        }

        public override string ToString()
        {
            return $"{this.GetType().Name} - {Legajo} - {Nombre}";
        }

        public static implicit operator Supervisor (string legajo)
        {
            return new Supervisor (legajo);
        }
    }
}
